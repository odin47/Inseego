(function() {
    'use strict';

    angular.module('inseego.home', []);
})();