//Author - Deepak Podili Devendra

(function () {
  'use strict';

  angular
    .module('inseego.widgets', ['smart-table', 'ngMaterial']);
}());
