require('angular-material-icons');
require('./dist/md-data-table-templates.js');
require('./dist/md-data-table.js');

module.exports = 'mdDataTable';
